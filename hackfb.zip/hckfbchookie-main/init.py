nama = 'usr'
